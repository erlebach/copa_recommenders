import pandas as pd
import numpy as np
import os
import regex as rex
from glob import glob
import pandas_options

low_files = glob("low*.txt")
high_files = glob("high*.txt")

df_low = {}
df_high = {}

for f in low_files:
    df_low[f[4:]] = pd.read_csv(f, delimiter='\t')

for f in high_files:
    df_high[f[5:]] = pd.read_csv(f, delimiter='\t')

#print(df_low['united_states.txt'])
print(df_low['honduras.txt'])
df = df_low['honduras.txt']
print(df.columns)
msg = df.iloc[3]['Jan']
print("str: ", rex.sub("[^0-9]+", "", msg))
#print(rex.replace("/D+", "", df.iloc[3]['Jan']))
#print(df.iloc[3]['Jan'].str(0,2))

msg = df['Jan']
print(msg)
xx = msg.apply(lambda x: rex.sub("[^0-9]+", "", x))
print(xx)

func = lambda x: x.replace(r"^([0-9]+)[^0-9].*$", r'\1', regex=True)
remove_uni = r"^([0-9]+)[^0-9].*$" 
dff = df.replace(remove_uni, r'\1', regex=True)

df = []
for k,v in df_low.items():
    # Replace column "Low" by City
    cols = df_low[k].columns
    #print("cols: ", cols)
    #print("cols[1:]: ", cols[1:])
    cols = ['City'] + list(cols[1:])
    #print("cols: ", cols)
    df_low[k].columns = cols
    df_low[k] = v.replace(remove_uni, r'\1', regex=True)
    df_low[k]['Country'] = k
    df_low[k]['Case'] = 'Low'
    df.append(df_low[k])

for k,v in df_high.items():
    # Replace column "Low" by City
    cols = df_high[k].columns
    cols = ['City'] + list(cols[1:])
    df_high[k].columns = cols
    df_high[k] = v.replace(remove_uni, r'\1', regex=True)
    df_high[k]['Country'] = k
    df_high[k]['Case'] = 'High'
    df.append(df_high[k])

dff = pd.concat(df, axis=0)
#print(dff)

#                       City Jan Feb Mar Apr May  Jun  Jul  Aug Sep Oct Nov  Dec            Country  Case
#0              Tegucigalpa   59  59  61  64  66   66   65   65  65  64  62   60       honduras.txt   Low
#1           San Pedro Sula   68  69  70  73  75   75   74   74  74  73  71   69       honduras.txt   Low

# Compute average temperature over the entire year, and over 4 season. Low and high. 
cols_months = dff.columns[1:-2]
cols_winter = dff.columns[1:4]
cols_spring = dff.columns[4:7]
cols_summer = dff.columns[7:10]
cols_fall   = dff.columns[10:-2]
print('cols_fall: ', cols_fall)
dff.loc[:,cols_months] = dff.loc[:,cols_months].astype('int') #.applymap(int)
dff['avg_yr'] = dff.loc[:,cols_months].mean(axis=1)
dff['winter'] = dff.loc[:,cols_winter].mean(axis=1)
dff['spring'] = dff.loc[:,cols_spring].mean(axis=1)
dff['summer'] = dff.loc[:,cols_summer].mean(axis=1)
dff['fall']   = dff.loc[:,cols_fall].mean(axis=1)
dff = dff.drop(cols_months, axis=1)

low  = dff[dff['Case'] == 'Low']
high = dff[dff['Case'] == 'High']
print("==============================")
print(low)
df_merge = low.merge(high, how='inner', on=['Country','City'], suffixes=('_l','_h'))
print(df_merge)

df_merge.to_csv("temperatures_countries.csv", index=0)
