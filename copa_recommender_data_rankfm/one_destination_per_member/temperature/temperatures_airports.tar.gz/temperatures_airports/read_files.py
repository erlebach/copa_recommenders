import pandas as pd
import pandas_options
import numpy as np
import os
import regex as rex
from glob import glob

low_files = glob("low*.txt")
high_files = glob("high*.txt")

airports = glob("[A-Z][A-Z][A-Z].txt")
print(airports)

air_df = []
remove_uni = r"^([0-9]+)[^0-9].*$" 

for f in airports:
    df = pd.read_csv(f, delimiter='\t')
    df = df.replace(remove_uni, r'\1', regex=True)
    df = df.iloc[[0,2],:]
    df['Airport'] = f[0:3]
    cols = df.columns
    cols = ['T'] + list(cols[1:])
    df.columns = cols
    air_df.append(df)

air_dff = pd.concat(air_df, axis=0)
month = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

dff = air_dff.copy()
cols_months = dff.columns[1:-1]
cols_winter = dff.columns[1:4]
cols_spring = dff.columns[4:7]
cols_summer = dff.columns[7:10]
cols_fall   = dff.columns[10:-1]
print('cols_fall: ', cols_fall)
print( dff.loc[:, cols_months] )
dff.loc[:,cols_months] = dff.loc[:,cols_months].astype('int') #.applymap(int)
dff['avg_yr'] = dff.loc[:,cols_months].mean(axis=1)
dff['winter'] = dff.loc[:,cols_winter].mean(axis=1)
dff['spring'] = dff.loc[:,cols_spring].mean(axis=1)
dff['summer'] = dff.loc[:,cols_summer].mean(axis=1)
dff['fall']   = dff.loc[:,cols_fall].mean(axis=1)
dff = dff.drop(cols_months, axis=1)
print(dff)

low = dff[dff['T'].str[0:3] == 'Low']
high = dff[dff['T'].str[0:4] == 'High']
df = low.merge(high, on='Airport', suffixes=('_l','_h'))
print(df)
df.to_csv("some_airport_temperatures.csv", index=0)
quit()
