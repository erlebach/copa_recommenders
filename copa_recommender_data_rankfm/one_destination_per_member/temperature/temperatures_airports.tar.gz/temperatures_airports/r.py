import pandas as pd
import numpy as np
import os
import regex as rex
from glob import glob
import pandas_options

low_files = glob("low*.txt")
high_files = glob("high*.txt")

df_low = {}
df_high = {}

for f in low_files:
    df_low[f[4:]] = pd.read_csv(f, delimiter='\t')

for f in high_files:
    df_high[f[5:]] = pd.read_csv(f, delimiter='\t')

#print(df_low['united_states.txt'])
print(df_low['honduras.txt'])
df = df_low['honduras.txt']
print(df.columns)
msg = df.iloc[3]['Jan']
print("str: ", rex.sub("[^0-9]+", "", msg))
#print(rex.replace("/D+", "", df.iloc[3]['Jan']))
#print(df.iloc[3]['Jan'].str(0,2))

msg = df['Jan']
print(msg)
xx = msg.apply(lambda x: rex.sub("[^0-9]+", "", x))
print(xx)

func = lambda x: x.replace(r"^([0-9]+)[^0-9].*$", r'\1', regex=True)
remove_uni = r"^([0-9]+)[^0-9].*$" 
dff = df.replace(remove_uni, r'\1', regex=True)

df = []
for k,v in df_low.items():
    # Replace column "Low" by City
    cols = df_low[k].columns
    #print("cols: ", cols)
    #print("cols[1:]: ", cols[1:])
    cols = ['City'] + list(cols[1:])
    #print("cols: ", cols)
    df_low[k].columns = cols
    df_low[k] = v.replace(remove_uni, r'\1', regex=True)
    df_low[k]['Country'] = k
    df_low[k]['Case'] = 'Low'
    df.append(df_low[k])

for k,v in df_high.items():
    # Replace column "Low" by City
    cols = df_high[k].columns
    cols = ['City'] + list(cols[1:])
    df_high[k].columns = cols
    df_high[k] = v.replace(remove_uni, r'\1', regex=True)
    df_high[k]['Country'] = k
    df_high[k]['Case'] = 'High'
    df.append(df_high[k])

dff = pd.concat(df, axis=0)
print(dff)

#print(df_low)
#print(df_high)

# Create a single dataframe with City, Country, Low, High temperatures per month

